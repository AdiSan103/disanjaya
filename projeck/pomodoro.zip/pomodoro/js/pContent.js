// animation menggunakan jquery

//parallax

//for pomodoro
//when pomodoro page start or load
$(window).on('load', function() {
	$('.pContent').addClass('movePContent')
});